#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("\n=== Working With VSCode ===\n\n");

    int girls = 12;
    int boys = 9;
    int students = girls + boys;

    printf("In the classroom, there are:\n");
    printf("\t%d girls\n", girls);
    printf("\t%d boys\n", boys);
    printf("giving a total of %d students.\n", students);

    printf("\n\n=== ByteGarage ===\n\n");
    return EXIT_SUCCESS;
}
