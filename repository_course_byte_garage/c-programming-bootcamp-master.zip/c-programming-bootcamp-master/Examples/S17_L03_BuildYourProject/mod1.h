#ifndef MOD1_H
#define MOD1_H

#include "led.h"

void print_mod1();

#endif