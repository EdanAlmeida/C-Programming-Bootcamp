#include <stdio.h>
#include <stdlib.h>

#include "mod1.h"
#include "mod2.h"

int main()
{
    printf("\n=== Build Your Project ===\n\n");

    print_mod1();
    print_mod2();

    printf("\n\n=== ByteGarage ===\n\n");
    return EXIT_SUCCESS;
}
