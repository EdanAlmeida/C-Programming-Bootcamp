#ifndef LED_H
#define LED_H

#define LED_ON  1
#define LED_OFF 0

typedef int Led;

void print_led_state(Led led);

#endif