#ifndef MOD2_H
#define MOD2_H

#include "led.h"

void print_mod2();

#endif