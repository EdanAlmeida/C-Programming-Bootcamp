#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main()
{
    bool a = true;
    bool b = false;

    printf("a (true):   %d\n", a);
    printf("b (false):  %d\n", b);

    printf("\n\n=== ByteGarage  ===\n\n");
    return EXIT_SUCCESS;
}
