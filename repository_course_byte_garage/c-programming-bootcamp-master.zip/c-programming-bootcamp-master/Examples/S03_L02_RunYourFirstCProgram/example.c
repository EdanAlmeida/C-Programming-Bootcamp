#include <stdio.h>
#include <stdlib.h>


int main()
{
    int number = 10000;
    printf("Hello world!\n");
    return EXIT_SUCCESS;
}