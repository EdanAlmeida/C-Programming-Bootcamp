# C Programming Bootcamp

Welcome to **[Byte Garage](https://bytegarage.co/)**'s brand new C Programming Bootcamp!

Here you can find all the examples and challenges that are faced during the course.

## Template

Copy and paste the Template folder to speed up the startup of your next C program in [Visual Studio Code](https://code.visualstudio.com/docs/languages/cpp#_hello-world).

